
import React, { useState, useCallback } from 'react';
import { ImageFile, AnalysisResult } from './types';
import { analyzeImageBatch } from './services/geminiService';
import { FileUpload } from './components/FileUpload';
import { ImageCard } from './components/ImageCard';
import { Header } from './components/Header';
import { ActionButtons } from './components/ActionButtons';

const MAX_FILES = 20;

const App: React.FC = () => {
  const [imageFiles, setImageFiles] = useState<ImageFile[]>([]);
  const [error, setError] = useState<string | null>(null);
  const [isAnalyzing, setIsAnalyzing] = useState(false);

  const handleFilesChange = (files: FileList | null) => {
    setError(null);
    if (!files) return;

    if (files.length + imageFiles.length > MAX_FILES) {
      setError(`You can only upload a maximum of ${MAX_FILES} images in total.`);
      return;
    }

    const newImageFiles: ImageFile[] = Array.from(files).map(file => ({
      id: `${file.name}-${file.lastModified}-${Math.random()}`,
      file,
      previewUrl: URL.createObjectURL(file),
      status: 'pending',
    }));

    setImageFiles(prev => [...prev, ...newImageFiles]);
  };

  const handleAnalyze = useCallback(async () => {
    const filesToAnalyze = imageFiles.filter(f => f.status === 'pending');
    if (filesToAnalyze.length === 0) return;

    setIsAnalyzing(true);
    setImageFiles(prev =>
      prev.map(f => (f.status === 'pending' ? { ...f, status: 'analyzing' } : f))
    );

    try {
      const results = await analyzeImageBatch(filesToAnalyze);
      setImageFiles(prev =>
        prev.map(file => {
          const result = results.find(r => r.id === file.id);
          if (result) {
            // FIX: Use the `in` operator for type guarding. This is a more robust way to narrow down the
            // discriminated union and helps TypeScript correctly infer the type in each branch.
            if ("error" in result) {
              return { ...file, status: 'error', error: result.error };
            } else {
              return { ...file, status: 'completed', result: result.data };
            }
          }
          return file;
        })
      );
    } catch (err) {
      setError('An unexpected error occurred during analysis. Please try again.');
      // Reset status for files that were being analyzed
      setImageFiles(prev =>
        prev.map(f =>
          f.status === 'analyzing' ? { ...f, status: 'pending', error: 'Analysis failed' } : f
        )
      );
    } finally {
      setIsAnalyzing(false);
    }
  }, [imageFiles]);

  const handleClear = () => {
    imageFiles.forEach(f => URL.revokeObjectURL(f.previewUrl));
    setImageFiles([]);
    setError(null);
    setIsAnalyzing(false);
  };
  
  const handleRemoveImage = (id: string) => {
    setImageFiles(prev => {
        const imageToRemove = prev.find(f => f.id === id);
        if (imageToRemove) {
            URL.revokeObjectURL(imageToRemove.previewUrl);
        }
        return prev.filter(f => f.id !== id);
    });
  };

  return (
    <div className="min-h-screen bg-gray-900 text-gray-100 font-sans">
      <main className="container mx-auto px-4 py-8">
        <Header />

        {error && (
          <div className="bg-red-900/50 border border-red-700 text-red-300 px-4 py-3 rounded-lg relative my-4 text-center" role="alert">
            <strong className="font-bold">Error: </strong>
            <span className="block sm:inline">{error}</span>
          </div>
        )}

        {imageFiles.length === 0 && <FileUpload onFilesChange={handleFilesChange} maxFiles={MAX_FILES} />}
        
        {imageFiles.length > 0 && (
          <>
            <ActionButtons
              onAnalyze={handleAnalyze}
              onClear={handleClear}
              isAnalyzing={isAnalyzing}
              pendingCount={imageFiles.filter(f => f.status === 'pending').length}
            />

            <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 xl:grid-cols-5 gap-6 mt-8">
              {imageFiles.map(imageFile => (
                <ImageCard key={imageFile.id} imageFile={imageFile} onRemove={handleRemoveImage} />
              ))}
            </div>
          </>
        )}
      </main>
    </div>
  );
};

export default App;
